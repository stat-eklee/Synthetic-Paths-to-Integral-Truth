HOSTFILE=hostfile
ENCODED_WORLD_INFO=`python parse_hostfile.py --hostfile ${HOSTFILE}`

set -x 

read -r -d '' training_commands <<EOF
./examples/train_dpo.py \
     --save_path ./ckpt/Llama_ours \
     --save_steps -1 \
     --logging_steps 1 \
     --eval_steps -1 \
     --train_batch_size 256 \
     --micro_train_batch_size 1 \
     --pretrain meta-llama/Meta-Llama-3-8B-Instruct \
     --bf16 \
     --max_epochs 1 \
     --max_len 8192 \
     --zero_stage 3 \
     --beta 0.1 \
     --learning_rate 1e-5 \
     --dataset ./data/our_data.jsonl \
     --dataset_probs 1.0 \
     --prompt_key prompt \
     --chosen_key chosen \
     --rejected_key rejected \
     --flash_attn \
     --gradient_checkpointing \
     --ref_offload
EOF
     # --wandb [WANDB_TOKENS] or True (use wandb login command)
     # --ipo [for IPO]
     # --label_smoothing 0.1 [for cDPO]


deepspeed $training_commands

