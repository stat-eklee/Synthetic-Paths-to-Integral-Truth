# Welcome to OpenRLHF's documentation!

[OpenRLHF](https://github.com/OpenLLMAI/OpenRLHF)  is a Ray-based High-performance RLHF framework (support 70B+ models). 



# Introduction



# Installation

## nvidia-docker

## conda



# Usages

## Quick start



## Examples



# API

## Datas



## Models



## Configs



## Trainers



## Pipelines



## Utils

