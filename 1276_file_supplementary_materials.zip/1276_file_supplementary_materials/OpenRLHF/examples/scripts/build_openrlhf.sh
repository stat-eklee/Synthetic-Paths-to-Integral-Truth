set -x

pip install --user ../../ 